package com.example.data.local

import androidx.sqlite.db.SupportSQLiteDatabase
import org.junit.After
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Before
import org.junit.Test
import java.io.File
import java.lang.reflect.Proxy
import java.sql.Connection
import java.sql.DriverManager
import java.sql.ResultSet

/**
 * Room মাইগ্রেশন v5 → v7 বাস্তব ডেটাবেসে যাচাই — pure JVM, Android ছাড়া।
 *
 * কেন Robolectric নয়: Robolectric 4.16.1-এ SDK 36 চালাতে Java 21 দরকার, কিন্তু এই
 * ২ GiB কনটেইনারে JDK 21-এ Kotlin কম্পাইলার মেমোরি শেষ করে ফেলে। তাই Android
 * রানটাইম সম্পূর্ণ বাদ দিয়ে আসল SQLite (sqlite-jdbc) দিয়ে মাইগ্রেশন চালানো হচ্ছে।
 *
 * এতে যা সত্যিকারভাবে পরীক্ষা হয়:
 *  - Migrations.kt-এর আসল MIGRATION_5_6 ও MIGRATION_6_7 কোড চলে (নকল নয়)।
 *  - আসল SQLite ফাইলে আসল SQL চলে, ডেটা সত্যিই সংরক্ষিত থাকে।
 *  - মাইগ্রেশনের পর স্কিমা 7.json-এর সাথে হুবহু মেলে কি না।
 *
 * যা পরীক্ষা হয় না (সীমাবদ্ধতা): Room-এর নিজের identityHash / RoomOpenHelper
 * ভ্যালিডেশন — সেটি Android রানটাইম ছাড়া চলে না। তাই স্কিমা মিল 7.json-এর
 * createSql-এর সাথে সরাসরি তুলনা করে যাচাই করা হয়েছে।
 */
class MigrationV5ToV7Test {

    private lateinit var dbFile: File
    private val connections = mutableListOf<Connection>()

    /** v7 identity hash — AppDatabase_Impl.kt থেকে নেওয়া। */
    private val v7IdentityHash = "c91b2a655940202c40a68b94df17e472"

    // ---------------------------------------------------------------------
    // v5 স্কিমা — মাইগ্রেশনের আগের অবস্থা। products-এ reorderPoint/reorderQuantity নেই।
    // ---------------------------------------------------------------------
    private val v5CreateStatements = listOf(
        "CREATE TABLE IF NOT EXISTS `transactions` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `dateString` TEXT NOT NULL, `dateMillis` INTEGER NOT NULL, `type` TEXT NOT NULL, `method` TEXT NOT NULL, `flowDirection` TEXT NOT NULL, `amount` REAL NOT NULL, `senderAccount` TEXT NOT NULL, `receiverAccount` TEXT NOT NULL, `personName` TEXT NOT NULL, `description` TEXT NOT NULL, `rawCode` TEXT NOT NULL, `totalBillAmount` REAL NOT NULL, `paidAmount` REAL NOT NULL, `dueAmount` REAL NOT NULL, `quantity` INTEGER NOT NULL, `unitPrice` REAL NOT NULL, `dueDate` TEXT NOT NULL, `customerPhone` TEXT NOT NULL, `createdAt` INTEGER NOT NULL)",
        "CREATE TABLE IF NOT EXISTS `payment_accounts` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `accountNumber` TEXT NOT NULL, `accountCode` TEXT NOT NULL, `method` TEXT NOT NULL, `scope` TEXT NOT NULL, `note` TEXT NOT NULL, `isCustom` INTEGER NOT NULL, `sortOrder` INTEGER NOT NULL)",
        "CREATE TABLE IF NOT EXISTS `customers` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `phone` TEXT NOT NULL, `address` TEXT NOT NULL, `note` TEXT NOT NULL, `creditLimit` REAL NOT NULL, `createdAt` INTEGER NOT NULL)",
        "CREATE TABLE IF NOT EXISTS `payment_requests` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `customerId` INTEGER NOT NULL, `customerName` TEXT NOT NULL, `customerPhone` TEXT NOT NULL, `amount` REAL NOT NULL, `paymentMethod` TEXT NOT NULL, `senderCode` TEXT NOT NULL, `receiverCode` TEXT NOT NULL, `trxId` TEXT NOT NULL, `note` TEXT NOT NULL, `status` TEXT NOT NULL, `submissionDateMillis` INTEGER NOT NULL, `submissionDateString` TEXT NOT NULL, `reviewedDateMillis` INTEGER, `rejectionReason` TEXT NOT NULL)",
        // v5-এ products-এ মাত্র ৮ কলাম — reorder সেটিংস এখনো আসেনি।
        "CREATE TABLE IF NOT EXISTS `products` (`id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL, `name` TEXT NOT NULL, `category` TEXT NOT NULL, `buyPrice` REAL NOT NULL, `sellPrice` REAL NOT NULL, `stockQuantity` INTEGER NOT NULL, `isAvailable` INTEGER NOT NULL, `unit` TEXT NOT NULL)",
        "CREATE TABLE IF NOT EXISTS room_master_table (id INTEGER PRIMARY KEY,identity_hash TEXT)",
        "INSERT OR REPLACE INTO room_master_table (id,identity_hash) VALUES(42, '$v7IdentityHash')"
    )

    @Before
    fun setUp() {
        Class.forName("org.sqlite.JDBC")
        dbFile = File.createTempFile("migration_v5_v7_", ".db")
        dbFile.delete()
    }

    @After
    fun tearDown() {
        connections.forEach { runCatching { it.close() } }
        connections.clear()
        dbFile.delete()
    }

    // ---------------------------------------------------------------------
    // সহায়ক: JDBC সংযোগ
    // ---------------------------------------------------------------------
    private fun connect(): Connection {
        val c = DriverManager.getConnection("jdbc:sqlite:${dbFile.absolutePath}")
        connections.add(c)
        return c
    }

    /**
     * একটি java.sql.Connection-কে SupportSQLiteDatabase হিসেবে মুড়ে দেয়।
     *
     * Migration.migrate() শুধু execSQL() ডাকে, তাই dynamic proxy দিয়ে শুধু সেটিই
     * বাস্তবায়ন করা হয়েছে — বাকি সব মেথড স্পষ্টভাবে ব্যর্থ হয়, যাতে কোনো
     * অপ্রত্যাশিত কল চুপচাপ পাস না করে।
     */
    private fun supportDb(conn: Connection): SupportSQLiteDatabase {
        return Proxy.newProxyInstance(
            SupportSQLiteDatabase::class.java.classLoader,
            arrayOf(SupportSQLiteDatabase::class.java)
        ) { _, method, args ->
            when (method.name) {
                "execSQL" -> {
                    conn.createStatement().use { it.execute(args!![0] as String) }
                    null
                }
                "getVersion" -> versionOf(conn)
                "setVersion" -> {
                    conn.createStatement().use { it.execute("PRAGMA user_version = ${args!![0]}") }
                    null
                }
                "close" -> null
                "toString" -> "JdbcSupportDatabase(${dbFile.name})"
                "hashCode" -> System.identityHashCode(conn)
                "equals" -> false
                else -> throw UnsupportedOperationException(
                    "JVM মাইগ্রেশন টেস্টে '${method.name}' সমর্থিত নয়"
                )
            }
        } as SupportSQLiteDatabase
    }

    private fun versionOf(conn: Connection): Int =
        conn.createStatement().use { st ->
            st.executeQuery("PRAGMA user_version").use { rs -> if (rs.next()) rs.getInt(1) else 0 }
        }

    private fun exec(conn: Connection, sql: String) {
        conn.createStatement().use { it.execute(sql) }
    }

    private fun <T> query(conn: Connection, sql: String, read: (ResultSet) -> T): T =
        conn.createStatement().use { st -> st.executeQuery(sql).use { read(it) } }

    private fun count(conn: Connection, table: String): Int =
        query(conn, "SELECT COUNT(*) FROM `$table`") { if (it.next()) it.getInt(1) else -1 }

    /** PRAGMA table_info থেকে কলামের নাম (ক্রম অনুযায়ী)। */
    private fun columns(conn: Connection, table: String): List<String> =
        query(conn, "PRAGMA table_info(`$table`)") { rs ->
            val out = mutableListOf<String>()
            while (rs.next()) out.add(rs.getString("name"))
            out
        }

    /** PRAGMA table_info থেকে কলামের টাইপ। */
    private fun columnTypes(conn: Connection, table: String): Map<String, String> =
        query(conn, "PRAGMA table_info(`$table`)") { rs ->
            val out = linkedMapOf<String, String>()
            while (rs.next()) out[rs.getString("name")] = rs.getString("type")
            out
        }

    // ---------------------------------------------------------------------
    // v5 ডেটাবেস তৈরি + নমুনা ডেটা
    // ---------------------------------------------------------------------
    private fun createV5DatabaseWithSampleData(): Connection {
        val conn = connect()
        v5CreateStatements.forEach { exec(conn, it) }

        exec(conn, "INSERT INTO `products` (`id`,`name`,`category`,`buyPrice`,`sellPrice`,`stockQuantity`,`isAvailable`,`unit`) VALUES (1,'স্মার্টফোন','ইলেকট্রনিক্স',15000.0,17500.0,12,1,'পিস')")
        exec(conn, "INSERT INTO `products` (`id`,`name`,`category`,`buyPrice`,`sellPrice`,`stockQuantity`,`isAvailable`,`unit`) VALUES (2,'হেডফোন','ইলেকট্রনিক্স',800.0,1200.0,3,1,'পিস')")
        exec(conn, "INSERT INTO `products` (`id`,`name`,`category`,`buyPrice`,`sellPrice`,`stockQuantity`,`isAvailable`,`unit`) VALUES (3,'চার্জার কেবল','এক্সেসরিজ',90.0,150.0,40,1,'পিস')")

        exec(conn, "INSERT INTO `customers` (`id`,`name`,`phone`,`address`,`note`,`creditLimit`,`createdAt`) VALUES (1,'হাসান ভাই','01711223344','ঢাকা','নিয়মিত',5000.0,1000)")
        exec(conn, "INSERT INTO `customers` (`id`,`name`,`phone`,`address`,`note`,`creditLimit`,`createdAt`) VALUES (2,'রফিক স্টোর','01899887766','চট্টগ্রাম','',2000.0,2000)")

        exec(conn, "INSERT INTO `transactions` (`id`,`dateString`,`dateMillis`,`type`,`method`,`flowDirection`,`amount`,`senderAccount`,`receiverAccount`,`personName`,`description`,`rawCode`,`totalBillAmount`,`paidAmount`,`dueAmount`,`quantity`,`unitPrice`,`dueDate`,`customerPhone`,`createdAt`) VALUES (1,'১০ সেপ্টেম্বর',1000,'SELL','BKASH','INCOMING',3500.0,'915','689','হাসান ভাই','হেডফোন বিক্রি','',3500.0,3500.0,0.0,1,3500.0,'','01711223344',1000)")
        exec(conn, "INSERT INTO `transactions` (`id`,`dateString`,`dateMillis`,`type`,`method`,`flowDirection`,`amount`,`senderAccount`,`receiverAccount`,`personName`,`description`,`rawCode`,`totalBillAmount`,`paidAmount`,`dueAmount`,`quantity`,`unitPrice`,`dueDate`,`customerPhone`,`createdAt`) VALUES (2,'১০ সেপ্টেম্বর',2000,'BUY','NAGAD','OUTGOING',12000.0,'','','','ডিসপ্লে পাইকারি ক্রয়','',12000.0,12000.0,0.0,0,0.0,'','',2000)")
        exec(conn, "INSERT INTO `transactions` (`id`,`dateString`,`dateMillis`,`type`,`method`,`flowDirection`,`amount`,`senderAccount`,`receiverAccount`,`personName`,`description`,`rawCode`,`totalBillAmount`,`paidAmount`,`dueAmount`,`quantity`,`unitPrice`,`dueDate`,`customerPhone`,`createdAt`) VALUES (3,'১১ সেপ্টেম্বর',3000,'EXPENSE','CASH','OUTGOING',500.0,'','','','দোকান চা-নাস্তা খরচ','',500.0,500.0,0.0,0,0.0,'','',3000)")

        exec(conn, "INSERT INTO `payment_accounts` (`id`,`accountNumber`,`accountCode`,`method`,`scope`,`note`,`isCustom`,`sortOrder`) VALUES (1,'01711223344','915','BKASH','PERSONAL','',0,1)")
        exec(conn, "INSERT INTO `payment_accounts` (`id`,`accountNumber`,`accountCode`,`method`,`scope`,`note`,`isCustom`,`sortOrder`) VALUES (2,'01899887766','689','NAGAD','PERSONAL','',0,2)")

        exec(conn, "INSERT INTO `payment_requests` (`id`,`customerId`,`customerName`,`customerPhone`,`amount`,`paymentMethod`,`senderCode`,`receiverCode`,`trxId`,`note`,`status`,`submissionDateMillis`,`submissionDateString`,`reviewedDateMillis`,`rejectionReason`) VALUES (1,1,'হাসান ভাই','01711223344',1500.0,'BKASH','915','689','TRX123','','PENDING',5000,'১০ সেপ্টেম্বর',NULL,'')")

        exec(conn, "PRAGMA user_version = 5")
        return conn
    }

    // ---------------------------------------------------------------------
    // 7.json থেকে প্রত্যাশিত স্কিমা পড়া (স্কিমা-ভ্যালিডেশনের বিকল্প)
    // ---------------------------------------------------------------------
    private fun expectedSchemaFromJson(): Map<String, List<String>> {
        val candidates = listOf(
            File("schemas/com.example.data.local.AppDatabase/7.json"),
            File("app/schemas/com.example.data.local.AppDatabase/7.json")
        )
        val json = candidates.firstOrNull { it.exists() }?.readText()
            ?: error("7.json পাওয়া যায়নি — খোঁজা হয়েছে: ${candidates.map { it.absolutePath }}")

        val result = linkedMapOf<String, List<String>>()
        // প্রতিটি "tableName": "X" ... "createSql": "..." জোড়া বের করছি।
        val tableRe = Regex("\"tableName\"\\s*:\\s*\"([^\"]+)\"")
        val sqlRe = Regex("\"createSql\"\\s*:\\s*\"((?:[^\"\\\\]|\\\\.)*)\"")
        val tableMatches = tableRe.findAll(json).toList()
        val sqlMatches = sqlRe.findAll(json).toList()
        assertEquals("7.json-এ টেবিল ও createSql সংখ্যা মিলছে না", tableMatches.size, sqlMatches.size)

        tableMatches.forEachIndexed { i, tm ->
            val table = tm.groupValues[1]
            val sql = sqlMatches[i].groupValues[1]
            // createSql-এ ব্যাকটিক-কোটা শুধু কলামের নামেই আছে (টেবিল নাম ${TABLE_NAME})।
            val cols = Regex("`([A-Za-z_][A-Za-z0-9_]*)`")
                .findAll(sql)
                .map { it.groupValues[1] }
                .toList()
            result[table] = cols
        }
        return result
    }

    // =====================================================================
    // ১. মূল পরীক্ষা — v5 → v7 একসাথে, ডেটা অক্ষত + স্কিমা সঠিক
    // =====================================================================
    @Test
    fun `v5 to v7 migration preserves all data and produces correct schema`() {
        val conn = createV5DatabaseWithSampleData()
        val support = supportDb(conn)

        // --- মাইগ্রেশন চালাও (আসল Migrations.kt কোড) ---
        MIGRATION_5_6.migrate(support)
        MIGRATION_6_7.migrate(support)
        support.version = 7

        // --- পুরোনো ডেটা অক্ষত? ---
        assertEquals("products সারি হারিয়েছে", 3, count(conn, "products"))
        assertEquals("customers সারি হারিয়েছে", 2, count(conn, "customers"))
        assertEquals("transactions সারি হারিয়েছে", 3, count(conn, "transactions"))
        assertEquals("payment_accounts সারি হারিয়েছে", 2, count(conn, "payment_accounts"))
        assertEquals("payment_requests সারি হারিয়েছে", 1, count(conn, "payment_requests"))

        // --- নির্দিষ্ট মান অক্ষত? (শুধু সংখ্যা নয়, বিষয়বস্তুও) ---
        query(conn, "SELECT `name`,`stockQuantity`,`buyPrice` FROM `products` WHERE `id`=1") { rs ->
            assertTrue(rs.next())
            assertEquals("স্মার্টফোন", rs.getString(1))
            assertEquals(12, rs.getInt(2))
            assertEquals(15000.0, rs.getDouble(3), 0.01)
        }
        query(conn, "SELECT `description`,`amount` FROM `transactions` WHERE `id`=1") { rs ->
            assertTrue(rs.next())
            assertEquals("হেডফোন বিক্রি", rs.getString(1))
            assertEquals(3500.0, rs.getDouble(2), 0.01)
        }
        query(conn, "SELECT `name`,`creditLimit` FROM `customers` WHERE `id`=2") { rs ->
            assertTrue(rs.next())
            assertEquals("রফিক স্টোর", rs.getString(1))
            assertEquals(2000.0, rs.getDouble(2), 0.01)
        }

        // --- নতুন কলাম যোগ হয়েছে? ---
        val productCols = columns(conn, "products")
        assertTrue("reorderPoint কলাম নেই", productCols.contains("reorderPoint"))
        assertTrue("reorderQuantity কলাম নেই", productCols.contains("reorderQuantity"))
        assertEquals("products-এ কলাম সংখ্যা ভুল: $productCols", 10, productCols.size)

        // --- পুরোনো পণ্য ডিফল্ট মান পেয়েছে? (NULL নয়) ---
        query(conn, "SELECT `reorderPoint`,`reorderQuantity` FROM `products` WHERE `id`=1") { rs ->
            assertTrue(rs.next())
            assertEquals("reorderPoint ডিফল্ট ভুল", 5, rs.getInt(1))
            assertEquals("reorderQuantity ডিফল্ট ভুল", 10, rs.getInt(2))
        }

        // --- stock_movements টেবিল: ঠিক ১১ কলাম, সঠিক ক্রমে ---
        val movementCols = columns(conn, "stock_movements")
        assertEquals("stock_movements-এ কলাম সংখ্যা ১১ নয়: $movementCols", 11, movementCols.size)
        assertEquals(
            listOf(
                "id", "productId", "productName", "type", "quantity", "delta",
                "resultingOnHand", "reason", "referenceId", "occurredAt", "dateString"
            ),
            movementCols
        )
        assertEquals("নতুন টেবিলে সারি থাকা উচিত নয়", 0, count(conn, "stock_movements"))

        // --- user_version সত্যিই ৭? ---
        assertEquals("user_version ৭ নয়", 7, versionOf(conn))
    }

    // =====================================================================
    // ২. স্কিমা 7.json-এর সাথে হুবহু মেলে? (Room ভ্যালিডেশনের বিকল্প)
    // =====================================================================
    @Test
    fun `migrated schema matches the exported v7 schema json`() {
        val conn = createV5DatabaseWithSampleData()
        val support = supportDb(conn)
        MIGRATION_5_6.migrate(support)
        MIGRATION_6_7.migrate(support)
        support.version = 7

        val expected = expectedSchemaFromJson()
        assertEquals("7.json-এ ৬টি টেবিল থাকা উচিত", 6, expected.size)

        expected.forEach { (table, expectedCols) ->
            val actualCols = columns(conn, table)
            assertEquals(
                "টেবিল '$table'-এর কলাম 7.json-এর সাথে মিলছে না",
                expectedCols, actualCols
            )
        }

        // টাইপও মিলছে কি না — stock_movements-এর জন্য
        val types = columnTypes(conn, "stock_movements")
        assertEquals("INTEGER", types["id"])
        assertEquals("INTEGER", types["productId"])
        assertEquals("TEXT", types["productName"])
        assertEquals("TEXT", types["type"])
        assertEquals("INTEGER", types["quantity"])
        assertEquals("INTEGER", types["delta"])
        assertEquals("INTEGER", types["resultingOnHand"])
        assertEquals("TEXT", types["reason"])
        assertEquals("INTEGER", types["referenceId"])
        assertEquals("INTEGER", types["occurredAt"])
        assertEquals("TEXT", types["dateString"])
    }

    // =====================================================================
    // ৩. আলাদা আলাদা ধাপ — প্রতিটির পর ফাইল বন্ধ করে আবার খোলা
    // =====================================================================
    @Test
    fun `each migration step works in isolation with reopen between steps`() {
        // --- ধাপ ১: MIGRATION_5_6 একা ---
        var conn = createV5DatabaseWithSampleData()
        MIGRATION_5_6.migrate(supportDb(conn))
        conn.createStatement().use { it.execute("PRAGMA user_version = 6") }
        conn.close()

        // ফাইল বন্ধ করে আবার খুলছি — ডেটা সত্যিই ডিস্কে গেছে কি না প্রমাণ।
        conn = connect()
        assertEquals("MIGRATION_5_6-এর পর stock_movements-এ ১১ কলাম নয়", 11, columns(conn, "stock_movements").size)
        assertEquals("MIGRATION_5_6-এ ডেটা হারিয়েছে", 3, count(conn, "products"))
        assertEquals("MIGRATION_5_6-এর পর products-এ ৮ কলাম থাকা উচিত", 8, columns(conn, "products").size)
        assertEquals("MIGRATION_5_6-এর পর user_version ৬ নয়", 6, versionOf(conn))

        // --- ধাপ ২: MIGRATION_6_7 একা ---
        MIGRATION_6_7.migrate(supportDb(conn))
        conn.createStatement().use { it.execute("PRAGMA user_version = 7") }
        conn.close()

        conn = connect()
        val prodAfter67 = columns(conn, "products")
        assertEquals("MIGRATION_6_7-এর পর products-এ ১০ কলাম নয়: $prodAfter67", 10, prodAfter67.size)
        assertTrue(prodAfter67.contains("reorderPoint"))
        assertTrue(prodAfter67.contains("reorderQuantity"))
        assertEquals("MIGRATION_6_7-এ ডেটা হারিয়েছে", 3, count(conn, "products"))
        query(conn, "SELECT `reorderPoint` FROM `products` WHERE `id`=2") { rs ->
            assertTrue(rs.next())
            assertEquals(5, rs.getInt(1))
        }
        assertEquals("user_version ৭ নয়", 7, versionOf(conn))
    }

    // =====================================================================
    // ৪. মাইগ্রেশনের পর লেজার সত্যিই কাজ করে? (রাইট পাথ প্রমাণ)
    // =====================================================================
    @Test
    fun `ledger table accepts movements and computes on-hand after migration`() {
        val conn = createV5DatabaseWithSampleData()
        val support = supportDb(conn)
        MIGRATION_5_6.migrate(support)
        MIGRATION_6_7.migrate(support)
        support.version = 7

        // পণ্য ২-এর স্টক ৩ → সমন্বয় করে ৮ (delta +5)
        exec(
            conn,
            "INSERT INTO `stock_movements` (`productId`,`productName`,`type`,`quantity`,`delta`,`resultingOnHand`,`reason`,`referenceId`,`occurredAt`,`dateString`) " +
                "VALUES (2,'হেডফোন','ADJUST_INCREASE',5,5,8,'ম্যানুয়াল গণনা',0,9000,'২৪ অক্টোবর')"
        )
        // আরেকটি মুভমেন্ট — বিক্রয় (delta -2)
        exec(
            conn,
            "INSERT INTO `stock_movements` (`productId`,`productName`,`type`,`quantity`,`delta`,`resultingOnHand`,`reason`,`referenceId`,`occurredAt`,`dateString`) " +
                "VALUES (2,'হেডফোন','SALE_OUT',2,-2,6,'বিক্রয়',77,9500,'২৪ অক্টোবর')"
        )

        assertEquals("লেজারে ২টি সারি থাকা উচিত", 2, count(conn, "stock_movements"))

        // লেজার-হিসাবকৃত স্টক = SUM(delta) = 5 - 2 = 3
        query(conn, "SELECT COALESCE(SUM(delta),0) FROM `stock_movements` WHERE productId=2") { rs ->
            assertTrue(rs.next())
            assertEquals("লেজার-হিসাবকৃত স্টক ভুল", 3, rs.getInt(1))
        }

        // ProductStockRow-এর কুয়েরি (StockMovementDao থেকে) সত্যিই চলে?
        query(
            conn,
            """
            SELECT p.id AS id, p.name AS name, p.category AS category, p.unit AS unit,
                   p.buyPrice AS buyPrice, p.sellPrice AS sellPrice,
                   p.stockQuantity AS stockQuantity, p.isAvailable AS isAvailable,
                   p.reorderPoint AS reorderPoint, p.reorderQuantity AS reorderQuantity,
                   COALESCE((SELECT SUM(m.delta) FROM stock_movements m WHERE m.productId = p.id), 0) AS ledgerOnHand,
                   COALESCE((SELECT MAX(m.occurredAt) FROM stock_movements m WHERE m.productId = p.id), 0) AS lastMovementAt
            FROM products p
            ORDER BY p.name ASC
            """.trimIndent()
        ) { rs ->
            var rows = 0
            var headphoneLedger = -1
            var headphoneLast = -1L
            while (rs.next()) {
                rows++
                if (rs.getLong("id") == 2L) {
                    headphoneLedger = rs.getInt("ledgerOnHand")
                    headphoneLast = rs.getLong("lastMovementAt")
                }
            }
            assertEquals("ProductStockRow কুয়েরি ৩টি সারি দেয়নি", 3, rows)
            assertEquals("হেডফোনের ledgerOnHand ভুল", 3, headphoneLedger)
            assertEquals("হেডফোনের lastMovementAt ভুল", 9500L, headphoneLast)
        }

        // লো-স্টক কুয়েরি (reorderPoint ভিত্তিক) — হেডফোনের স্টক ৩, reorderPoint ৫ → ধরা পড়বে
        query(conn, "SELECT COUNT(*) FROM `products` WHERE `stockQuantity` <= `reorderPoint`") { rs ->
            assertTrue(rs.next())
            assertEquals("লো-স্টক কুয়েরি ভুল সংখ্যা দিয়েছে", 1, rs.getInt(1))
        }
    }

    // =====================================================================
    // ৫. identity hash v7-এর সাথে মিলছে? (রেকর্ডকৃত মান যাচাই)
    // =====================================================================
    @Test
    fun `room master table carries the v7 identity hash`() {
        val conn = createV5DatabaseWithSampleData()
        val support = supportDb(conn)
        MIGRATION_5_6.migrate(support)
        MIGRATION_6_7.migrate(support)
        support.version = 7

        query(conn, "SELECT identity_hash FROM room_master_table WHERE id=42") { rs ->
            assertTrue("room_master_table-এ সারি নেই", rs.next())
            assertEquals("identity hash v7-এর সাথে মিলছে না", v7IdentityHash, rs.getString(1))
        }
        assertNotNull(v7IdentityHash)
    }
}
