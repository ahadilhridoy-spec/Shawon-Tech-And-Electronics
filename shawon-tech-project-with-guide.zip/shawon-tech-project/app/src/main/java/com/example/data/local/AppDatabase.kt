package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.data.model.CustomerEntity
import com.example.data.model.PaymentAccountEntity
import com.example.data.model.PaymentRequestEntity
import com.example.data.model.ProductItemEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.TransactionEntity

@Database(
    entities = [
        TransactionEntity::class,
        PaymentAccountEntity::class,
        CustomerEntity::class,
        PaymentRequestEntity::class,
        ProductItemEntity::class,
        StockMovementEntity::class
    ],
    version = 7,
    exportSchema = true
)
abstract class AppDatabase : RoomDatabase() {
    abstract fun transactionDao(): TransactionDao
    abstract fun paymentAccountDao(): PaymentAccountDao
    abstract fun customerDao(): CustomerDao
    abstract fun paymentRequestDao(): PaymentRequestDao
    abstract fun productDao(): ProductDao
    abstract fun stockMovementDao(): StockMovementDao

    companion object {
        @Volatile
        private var INSTANCE: AppDatabase? = null

        fun getDatabase(context: Context): AppDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    AppDatabase::class.java,
                    "shawon_tech_database"
                )
                    // fallbackToDestructiveMigration() সরানো হয়েছে।
                    // আগে version বাড়ালেই Room সব টেবিল মুছে খালি করে দিত —
                    // কোনো এরর ছাড়াই দোকানের সব লেনদেন হারিয়ে যেত।
                    // এখন প্রতিটি স্কিমা পরিবর্তনের জন্য Migrations.kt-এ
                    // একটি স্পষ্ট মাইগ্রেশন থাকতে হবে, নাহলে Room স্পষ্টভাবে
                    // ব্যর্থ হবে — নিঃশব্দে ডেটা মুছবে না।
                    .addMigrations(*ALL_MIGRATIONS)
                    .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
