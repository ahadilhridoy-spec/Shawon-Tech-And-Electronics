package com.example.data.local

import androidx.room.migration.Migration
import androidx.sqlite.db.SupportSQLiteDatabase

/**
 * Room মাইগ্রেশন — fallbackToDestructiveMigration() সরানোর পর এগুলোই
 * ডেটা রক্ষা করে। প্রতিটি মাইগ্রেশন ঠিক ততটুকুই করে যতটুকু দরকার;
 * কোনো টেবিল ড্রপ করে না, কোনো ডেটা মুছে না।
 *
 * নিয়ম: একটি নতুন কলাম বা টেবিল যোগ করলে version বাড়াতে হবে এবং
 * এখানে একটি মাইগ্রেশন লিখতে হবে। নাহলে Room অ্যাপ চালু করার সময়
 * IllegalStateException ছুড়বে — যা ডেটা নিঃশব্দে মুছে ফেলার চেয়ে অনেক ভালো।
 */

/**
 * v5 → v6: স্টক লেজার টেবিল যোগ।
 *
 * বিদ্যমান কোনো টেবিল স্পর্শ করা হয় না — শুধু নতুন টেবিল তৈরি হয়।
 * তাই এই মাইগ্রেশনে ডেটা হারানোর কোনো ঝুঁকি নেই।
 */
val MIGRATION_5_6 = object : Migration(5, 6) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL(
            """
            CREATE TABLE IF NOT EXISTS `stock_movements` (
                `id` INTEGER PRIMARY KEY AUTOINCREMENT NOT NULL,
                `productId` INTEGER NOT NULL,
                `productName` TEXT NOT NULL,
                `type` TEXT NOT NULL,
                `quantity` INTEGER NOT NULL,
                `delta` INTEGER NOT NULL,
                `resultingOnHand` INTEGER NOT NULL,
                `reason` TEXT NOT NULL,
                `referenceId` INTEGER NOT NULL,
                `occurredAt` INTEGER NOT NULL,
                `dateString` TEXT NOT NULL
            )
            """.trimIndent()
        )
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_productId` ON `stock_movements` (`productId`)")
        db.execSQL("CREATE INDEX IF NOT EXISTS `index_stock_movements_occurredAt` ON `stock_movements` (`occurredAt`)")
    }
}

/**
 * v6 → v7: products টেবিলে রি-অর্ডার সেটিংস যোগ।
 *
 * DEFAULT মান দেওয়া হয়েছে, তাই বিদ্যমান প্রতিটি পণ্য একটি বৈধ মান পায়
 * (৫ পিস সীমা, ১০ পিস রি-অর্ডার) — কোনো সারি NULL থাকে না, কোনো ডেটা হারায় না।
 */
val MIGRATION_6_7 = object : Migration(6, 7) {
    override fun migrate(db: SupportSQLiteDatabase) {
        db.execSQL("ALTER TABLE `products` ADD COLUMN `reorderPoint` INTEGER NOT NULL DEFAULT 5")
        db.execSQL("ALTER TABLE `products` ADD COLUMN `reorderQuantity` INTEGER NOT NULL DEFAULT 10")
    }
}

/** সব মাইগ্রেশন একসাথে — AppDatabase.getDatabase()-এ পাস করার জন্য। */
val ALL_MIGRATIONS = arrayOf(MIGRATION_5_6, MIGRATION_6_7)
