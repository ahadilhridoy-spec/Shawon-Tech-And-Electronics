package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Edit
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductItemEntity
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.InflowGreen
import com.example.ui.theme.OutflowRed
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyPrimary
import com.example.ui.viewmodel.DashboardViewModel
import com.example.util.BanglaUtils

/**
 * পণ্য ব্যবস্থাপনা — সব পণ্য, স্টক, রি-অর্ডার সেটিংস ও লো-স্টক সতর্কতা।
 *
 * আগে পণ্য যোগ/সম্পাদনা শুধু কাস্টমার খাতার ভিতরে লুকানো ছিল।
 * এখন এটি একটি স্বতন্ত্র স্ক্রিন — "আরও" শিট থেকে খোলে।
 */
@Composable
fun ProductManagementScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.allProducts.collectAsState()
    val lowStockRows by viewModel.lowStockRows.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var showLowStockOnly by remember { mutableStateOf(false) }
    var editing by remember { mutableStateOf<ProductItemEntity?>(null) }
    var showEditor by remember { mutableStateOf(false) }
    var deleting by remember { mutableStateOf<ProductItemEntity?>(null) }

    val lowStockIds = lowStockRows.map { it.id }.toSet()
    val filtered = products.filter { p ->
        val matchesQuery = searchQuery.isBlank() ||
            p.name.contains(searchQuery, ignoreCase = true) ||
            p.category.contains(searchQuery, ignoreCase = true)
        val matchesFilter = !showLowStockOnly || p.id in lowStockIds
        matchesQuery && matchesFilter
    }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // ---------- header ----------
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TechNavyDark)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = GoldAccent,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(9.dp))
                    Text(
                        text = "পণ্য ব্যবস্থাপনা",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(12.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    HeaderStat(
                        label = "মোট পণ্য",
                        value = BanglaUtils.toBangla(products.size),
                        accent = Color.White,
                        modifier = Modifier.weight(1f)
                    )
                    HeaderStat(
                        label = "লো-স্টক",
                        value = BanglaUtils.toBangla(lowStockRows.size),
                        accent = if (lowStockRows.isEmpty()) InflowGreen else OutflowRed,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        // ---------- search + filter ----------
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("নাম বা ক্যাটাগরি...", fontSize = 13.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                singleLine = true,
                shape = RoundedCornerShape(12.dp),
                modifier = Modifier
                    .weight(1f)
                    .testTag("product_search")
            )
            FilterChip(
                selected = showLowStockOnly,
                onClick = { showLowStockOnly = !showLowStockOnly },
                label = { Text("লো-স্টক", fontSize = 11.sp) },
                modifier = Modifier.testTag("product_low_stock_filter")
            )
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                editing = null
                showEditor = true
            },
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 16.dp)
                .testTag("product_add_button"),
            colors = ButtonDefaults.buttonColors(containerColor = TechNavyPrimary),
            shape = RoundedCornerShape(12.dp)
        ) {
            Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.width(7.dp))
            Text("নতুন পণ্য যোগ করুন", fontWeight = FontWeight.Bold)
        }

        Spacer(modifier = Modifier.height(10.dp))

        if (filtered.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(32.dp),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (products.isEmpty()) "এখনো কোনো পণ্য নেই।" else "কোনো পণ্য পাওয়া যায়নি।",
                    fontSize = 13.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize(),
                contentPadding = androidx.compose.foundation.layout.PaddingValues(
                    start = 16.dp, end = 16.dp, bottom = 28.dp
                ),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                items(filtered, key = { it.id }) { product ->
                    ProductRow(
                        product = product,
                        isLowStock = product.id in lowStockIds,
                        onEdit = {
                            editing = product
                            showEditor = true
                        },
                        onToggle = { viewModel.toggleProductAvailability(product) },
                        onDelete = { deleting = product }
                    )
                }
            }
        }
    }

    // ---------- add / edit dialog ----------
    if (showEditor) {
        ProductEditorDialog(
            initial = editing,
            onDismiss = { showEditor = false },
            onSave = { name, category, buy, sell, stock, reorderPoint, reorderQty, available ->
                if (editing == null) {
                    viewModel.addProduct(name, category, buy, sell, stock, available)
                } else {
                    viewModel.updateProduct(
                        editing!!.copy(
                            name = name.trim(),
                            category = category.trim(),
                            buyPrice = buy,
                            sellPrice = sell,
                            stockQuantity = stock,
                            reorderPoint = reorderPoint,
                            reorderQuantity = reorderQty,
                            isAvailable = available
                        )
                    )
                }
                showEditor = false
                Toast.makeText(context, "পণ্য সংরক্ষিত হয়েছে", Toast.LENGTH_SHORT).show()
            }
        )
    }

    // ---------- delete confirm ----------
    deleting?.let { target ->
        AlertDialog(
            onDismissRequest = { deleting = null },
            title = { Text("পণ্য মুছবেন?") },
            text = { Text("${target.name} মুছে ফেলা হবে। এটি ফেরানো যাবে না।") },
            confirmButton = {
                TextButton(onClick = {
                    viewModel.deleteProduct(target)
                    deleting = null
                }) { Text("মুছুন", color = OutflowRed, fontWeight = FontWeight.Bold) }
            },
            dismissButton = {
                TextButton(onClick = { deleting = null }) { Text("বাতিল") }
            }
        )
    }
}

@Composable
private fun HeaderStat(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.08f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, fontSize = 10.5.sp, color = Color.White.copy(alpha = 0.75f))
            Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = accent)
        }
    }
}

@Composable
private fun ProductRow(
    product: ProductItemEntity,
    isLowStock: Boolean,
    onEdit: () -> Unit,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(product.name, fontSize = 15.sp, fontWeight = FontWeight.SemiBold)
                    Text(
                        text = "${product.category} · একক: ${product.unit}",
                        fontSize = 11.5.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                    )
                }
                if (isLowStock) {
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = OutflowRed.copy(alpha = 0.14f)
                    ) {
                        Row(
                            modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = OutflowRed,
                                modifier = Modifier.size(12.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(
                                text = "রি-অর্ডার",
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = OutflowRed
                            )
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = "স্টক: " + BanglaUtils.toBangla(product.stockQuantity),
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (product.stockQuantity <= 0) OutflowRed else InflowGreen
                    )
                    Text(
                        text = "ক্রয় ${BanglaUtils.formatTaka(product.buyPrice, useSymbol = true)} · " +
                            "বিক্রয় ${BanglaUtils.formatTaka(product.sellPrice, useSymbol = true)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                    Text(
                        text = "রি-অর্ডার সীমা: ${BanglaUtils.toBangla(product.reorderPoint)} · " +
                            "পরিমাণ: ${BanglaUtils.toBangla(product.reorderQuantity)}",
                        fontSize = 11.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                    )
                }
                Switch(
                    checked = product.isAvailable,
                    onCheckedChange = { onToggle() },
                    modifier = Modifier.testTag("product_available_${product.id}")
                )
            }

            Spacer(modifier = Modifier.height(4.dp))

            Row(horizontalArrangement = Arrangement.End, modifier = Modifier.fillMaxWidth()) {
                IconButton(
                    onClick = onEdit,
                    modifier = Modifier.testTag("product_edit_${product.id}")
                ) {
                    Icon(Icons.Default.Edit, contentDescription = "সম্পাদনা", tint = TechNavyPrimary)
                }
                IconButton(
                    onClick = onDelete,
                    modifier = Modifier.testTag("product_delete_${product.id}")
                ) {
                    Icon(Icons.Default.Delete, contentDescription = "মুছুন", tint = OutflowRed)
                }
            }
        }
    }
}

@Composable
private fun ProductEditorDialog(
    initial: ProductItemEntity?,
    onDismiss: () -> Unit,
    onSave: (String, String, Double, Double, Int, Int, Int, Boolean) -> Unit
) {
    var name by remember { mutableStateOf(initial?.name ?: "") }
    var category by remember { mutableStateOf(initial?.category ?: "") }
    var buyPrice by remember { mutableStateOf(initial?.buyPrice?.toLong()?.toString() ?: "190") }
    var sellPrice by remember { mutableStateOf(initial?.sellPrice?.toLong()?.toString() ?: "230") }
    var stock by remember { mutableStateOf(initial?.stockQuantity?.toString() ?: "0") }
    var reorderPoint by remember { mutableStateOf(initial?.reorderPoint?.toString() ?: "5") }
    var reorderQty by remember { mutableStateOf(initial?.reorderQuantity?.toString() ?: "10") }
    var available by remember { mutableStateOf(initial?.isAvailable ?: true) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text(if (initial == null) "নতুন পণ্য" else "পণ্য সম্পাদনা") },
        text = {
            Column {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("পণ্যের নাম *") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("product_name_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = category,
                    onValueChange = { category = it },
                    label = { Text("ক্যাটাগরি") },
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth()
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = buyPrice,
                        onValueChange = { buyPrice = it },
                        label = { Text("ক্রয় দর") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = sellPrice,
                        onValueChange = { sellPrice = it },
                        label = { Text("বিক্রয় দর") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(8.dp))
                OutlinedTextField(
                    value = stock,
                    onValueChange = { stock = it },
                    label = { Text("স্টক পরিমাণ") },
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                    singleLine = true,
                    shape = RoundedCornerShape(10.dp),
                    modifier = Modifier.fillMaxWidth().testTag("product_stock_input")
                )
                Spacer(modifier = Modifier.height(8.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = reorderPoint,
                        onValueChange = { reorderPoint = it },
                        label = { Text("রি-অর্ডার সীমা") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = reorderQty,
                        onValueChange = { reorderQty = it },
                        label = { Text("রি-অর্ডার পরিমাণ") },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp),
                        modifier = Modifier.weight(1f)
                    )
                }
                Spacer(modifier = Modifier.height(10.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Switch(checked = available, onCheckedChange = { available = it })
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("কাস্টমার পোর্টালে দেখান", fontSize = 13.sp)
                }
            }
        },
        confirmButton = {
            TextButton(
                onClick = {
                    if (name.isBlank()) return@TextButton
                    onSave(
                        name,
                        category,
                        buyPrice.toDoubleOrNull() ?: 190.0,
                        sellPrice.toDoubleOrNull() ?: 230.0,
                        stock.toIntOrNull() ?: 0,
                        reorderPoint.toIntOrNull() ?: 5,
                        reorderQty.toIntOrNull() ?: 10,
                        available
                    )
                },
                modifier = Modifier.testTag("product_save_button")
            ) { Text("সংরক্ষণ", fontWeight = FontWeight.Bold) }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("বাতিল") }
        }
    )
}
