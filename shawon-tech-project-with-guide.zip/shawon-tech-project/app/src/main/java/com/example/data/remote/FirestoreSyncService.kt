package com.example.data.remote

import android.content.Context
import android.util.Log
import com.example.R
import com.example.data.model.CustomerEntity
import com.example.data.model.PaymentAccountEntity
import com.example.data.model.PaymentRequestEntity
import com.example.data.model.ProductItemEntity
import com.example.data.model.StockMovementEntity
import com.example.data.model.TransactionEntity
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.SetOptions
import kotlinx.coroutines.tasks.await

class FirestoreSyncService(context: Context) {
    private val databaseId = context.getString(R.string.firestore_database_id)
    private val firestore: FirebaseFirestore = FirebaseFirestore.getInstance(databaseId)

    companion object {
        private const val TAG = "FirestoreSyncService"
    }

    suspend fun uploadTransaction(userId: String, transaction: TransactionEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("transactions").document(transaction.id.toString())

            val map = hashMapOf(
                "id" to transaction.id.toString(),
                "dateString" to transaction.dateString,
                "dateMillis" to transaction.dateMillis,
                "type" to transaction.type,
                "method" to transaction.method,
                "flowDirection" to transaction.flowDirection,
                "amount" to transaction.amount,
                "senderAccount" to transaction.senderAccount,
                "receiverAccount" to transaction.receiverAccount,
                "personName" to transaction.personName,
                "description" to transaction.description,
                "rawCode" to transaction.rawCode,
                "totalBillAmount" to transaction.totalBillAmount,
                "paidAmount" to transaction.paidAmount,
                "dueAmount" to transaction.dueAmount,
                "quantity" to transaction.quantity,
                "unitPrice" to transaction.unitPrice,
                "dueDate" to transaction.dueDate,
                "customerPhone" to transaction.customerPhone,
                "createdAt" to transaction.createdAt,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded transaction #${transaction.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload transaction #${transaction.id}", e)
        }
    }

    suspend fun uploadPaymentAccount(userId: String, account: PaymentAccountEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("payment_accounts").document(account.id.toString())

            val map = hashMapOf(
                "id" to account.id.toString(),
                "accountNumber" to account.accountNumber,
                "accountCode" to account.accountCode,
                "method" to account.method,
                "scope" to account.scope,
                "note" to account.note,
                "isCustom" to account.isCustom,
                "sortOrder" to account.sortOrder,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded payment account #${account.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload payment account #${account.id}", e)
        }
    }

    suspend fun deleteTransaction(userId: String, transactionId: Long) {
        if (userId.isBlank()) return
        try {
            firestore.collection("users").document(userId)
                .collection("transactions").document(transactionId.toString())
                .delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete transaction #$transactionId from Firestore", e)
        }
    }

    suspend fun deletePaymentAccount(userId: String, accountId: Long) {
        if (userId.isBlank()) return
        try {
            firestore.collection("users").document(userId)
                .collection("payment_accounts").document(accountId.toString())
                .delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete payment account #$accountId from Firestore", e)
        }
    }

    suspend fun syncAllTransactions(userId: String, transactions: List<TransactionEntity>) {
        if (userId.isBlank()) return
        transactions.forEach { uploadTransaction(userId, it) }
    }

    suspend fun syncAllAccounts(userId: String, accounts: List<PaymentAccountEntity>) {
        if (userId.isBlank()) return
        accounts.forEach { uploadPaymentAccount(userId, it) }
    }

    // ------------------------------------------------------------------
    // প্রোডাক্ট, কাস্টমার, পেমেন্ট রিকোয়েস্ট ও স্টক লেজার সিঙ্ক
    // ------------------------------------------------------------------

    /** পণ্য Firestore-এ আপলোড করে — স্টক ও রি-অর্ডার সেটিংস সহ। */
    suspend fun uploadProduct(userId: String, product: ProductItemEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("products").document(product.id.toString())

            val map = hashMapOf(
                "id" to product.id.toString(),
                "name" to product.name,
                "category" to product.category,
                "buyPrice" to product.buyPrice,
                "sellPrice" to product.sellPrice,
                "stockQuantity" to product.stockQuantity,
                "isAvailable" to product.isAvailable,
                "unit" to product.unit,
                "reorderPoint" to product.reorderPoint,
                "reorderQuantity" to product.reorderQuantity,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded product #${product.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload product #${product.id}", e)
        }
    }

    suspend fun deleteProduct(userId: String, productId: Long) {
        if (userId.isBlank()) return
        try {
            firestore.collection("users").document(userId)
                .collection("products").document(productId.toString())
                .delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete product #$productId from Firestore", e)
        }
    }

    /** কাস্টমার Firestore-এ আপলোড করে। */
    suspend fun uploadCustomer(userId: String, customer: CustomerEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("customers").document(customer.id.toString())

            val map = hashMapOf(
                "id" to customer.id.toString(),
                "name" to customer.name,
                "phone" to customer.phone,
                "address" to customer.address,
                "note" to customer.note,
                "creditLimit" to customer.creditLimit,
                "createdAt" to customer.createdAt,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded customer #${customer.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload customer #${customer.id}", e)
        }
    }

    suspend fun deleteCustomer(userId: String, customerId: Long) {
        if (userId.isBlank()) return
        try {
            firestore.collection("users").document(userId)
                .collection("customers").document(customerId.toString())
                .delete().await()
        } catch (e: Exception) {
            Log.e(TAG, "Failed to delete customer #$customerId from Firestore", e)
        }
    }

    /** কাস্টমারের পেমেন্ট রিকোয়েস্ট আপলোড করে। */
    suspend fun uploadPaymentRequest(userId: String, request: PaymentRequestEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("payment_requests").document(request.id.toString())

            val map = hashMapOf(
                "id" to request.id.toString(),
                "customerId" to request.customerId.toString(),
                "customerName" to request.customerName,
                "customerPhone" to request.customerPhone,
                "amount" to request.amount,
                "paymentMethod" to request.paymentMethod,
                "senderCode" to request.senderCode,
                "receiverCode" to request.receiverCode,
                "trxId" to request.trxId,
                "note" to request.note,
                "status" to request.status,
                "submissionDateMillis" to request.submissionDateMillis,
                "submissionDateString" to request.submissionDateString,
                "rejectionReason" to request.rejectionReason,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded payment request #${request.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload payment request #${request.id}", e)
        }
    }

    /** স্টক লেজার মুভমেন্ট আপলোড করে — অডিট ট্রেইল ক্লাউডে সংরক্ষিত থাকে। */
    suspend fun uploadStockMovement(userId: String, movement: StockMovementEntity) {
        if (userId.isBlank()) return
        try {
            val docRef = firestore.collection("users").document(userId)
                .collection("stock_movements").document(movement.id.toString())

            val map = hashMapOf(
                "id" to movement.id.toString(),
                "productId" to movement.productId.toString(),
                "productName" to movement.productName,
                "type" to movement.type,
                "quantity" to movement.quantity,
                "delta" to movement.delta,
                "resultingOnHand" to movement.resultingOnHand,
                "reason" to movement.reason,
                "referenceId" to movement.referenceId.toString(),
                "occurredAt" to movement.occurredAt,
                "dateString" to movement.dateString,
                "userId" to userId
            )
            docRef.set(map, SetOptions.merge()).await()
            Log.d(TAG, "Uploaded stock movement #${movement.id} to Firestore")
        } catch (e: Exception) {
            Log.e(TAG, "Failed to upload stock movement #${movement.id}", e)
        }
    }

    suspend fun syncAllProducts(userId: String, products: List<ProductItemEntity>) {
        if (userId.isBlank()) return
        products.forEach { uploadProduct(userId, it) }
    }

    suspend fun syncAllCustomers(userId: String, customers: List<CustomerEntity>) {
        if (userId.isBlank()) return
        customers.forEach { uploadCustomer(userId, it) }
    }

    suspend fun syncAllPaymentRequests(userId: String, requests: List<PaymentRequestEntity>) {
        if (userId.isBlank()) return
        requests.forEach { uploadPaymentRequest(userId, it) }
    }
}
