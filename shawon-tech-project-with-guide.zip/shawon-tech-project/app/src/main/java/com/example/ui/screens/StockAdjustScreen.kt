package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Inventory2
import androidx.compose.material.icons.filled.Receipt
import androidx.compose.material.icons.filled.Remove
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FilterChip
import androidx.compose.material3.HorizontalDivider
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ProductItemEntity
import com.example.data.model.StockAdjustMode
import com.example.data.model.StockMovementEntity
import com.example.data.model.StockMovementType
import com.example.data.model.computeStockAdjustPreview
import com.example.ui.theme.BrandCyanLight
import com.example.ui.theme.GoldAccent
import com.example.ui.theme.InflowGreen
import com.example.ui.theme.OutflowRed
import com.example.ui.theme.TechNavyDark
import com.example.ui.theme.TechNavyPrimary
import com.example.ui.viewmodel.DashboardViewModel
import com.example.util.BanglaUtils

/**
 * স্টক সমন্বয় — pick a product, say what happened, see the result before saving.
 *
 * Follows the same visual language as PersonalExpenseScreen / CustomerLedgerScreen:
 * dark header card, white surface cards, FilterChip selectors, LazyColumn of cards,
 * Toast for feedback. Every Bengali string is inline, matching the rest of the app.
 *
 * DATA NOTE — persists through DashboardViewModel.adjustStock(), which calls
 * TransactionRepository.applyStockAdjustment(). That writes a stock_movements ledger
 * row AND updates products.stockQuantity inside one Room transaction, so the ledger
 * and the cached quantity can never disagree. The recent-adjustments list below reads
 * straight from the ledger, not from session state.
 */
@Composable
fun StockAdjustScreen(
    viewModel: DashboardViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val products by viewModel.allProducts.collectAsState()
    // লেজার থেকে প্রকৃত অন-হ্যান্ড ও সাম্প্রতিক মুভমেন্ট — সেশন-স্কোপড নয়।
    val stockRows by viewModel.productStockRows.collectAsState()
    val recentMovements by viewModel.recentStockMovements.collectAsState()

    var selectedProduct by remember { mutableStateOf<ProductItemEntity?>(null) }
    var showPicker by remember { mutableStateOf(false) }
    var mode by remember { mutableStateOf(StockAdjustMode.SET_TO_COUNT) }
    var qtyInput by remember { mutableStateOf("") }
    var noteInput by remember { mutableStateOf("") }

    // Keep the inline preview in step with the live row: after a save the flow
    // re-emits the updated product, so `selectedProduct` is re-read from it.
    val liveProduct = selectedProduct?.let { sel -> products.firstOrNull { it.id == sel.id } }
    // অন-হ্যান্ড লেজার থেকে পড়া হয় — ক্যাশ করা মান নয়, তাই অমিল হতে পারে না।
    val currentOnHand = stockRows.firstOrNull { it.id == selectedProduct?.id }?.ledgerOnHand
        ?: liveProduct?.stockQuantity ?: 0
    val inputQty = qtyInput.toIntOrNull() ?: 0

    // The SAME pure function the save path uses — preview and result cannot disagree.
    val preview = computeStockAdjustPreview(currentOnHand, mode, inputQty)

    val outOfStockCount = products.count { it.stockQuantity <= 0 }

    Column(
        modifier = modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // ---------- 1. header ----------
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = TechNavyDark)
        ) {
            Column(modifier = Modifier.padding(16.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Inventory2,
                        contentDescription = null,
                        tint = TechNavyPrimary,
                        modifier = Modifier.size(22.dp)
                    )
                    Spacer(modifier = Modifier.width(9.dp))
                    Text(
                        text = "স্টক সমন্বয়",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = "গণনা মিলিয়ে স্টক ঠিক করুন",
                    fontSize = 12.sp,
                    color = Color.White.copy(alpha = 0.8f)
                )

                Spacer(modifier = Modifier.height(12.dp))
                HorizontalDivider(color = Color.White.copy(alpha = 0.15f))
                Spacer(modifier = Modifier.height(10.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    HeaderStat(
                        label = "মোট পণ্য",
                        value = BanglaUtils.toBangla(products.size.toString()),
                        accent = BrandCyanish(),
                        modifier = Modifier.weight(1f)
                    )
                    HeaderStat(
                        label = "স্টক শেষ",
                        value = BanglaUtils.toBangla(outOfStockCount.toString()),
                        accent = if (outOfStockCount > 0) OutflowRed else InflowGreen,
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        }

        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // ---------- 2. product picker ----------
            item {
                SectionCard {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "১. পণ্য বাছুন",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = TechNavyPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        if (products.isNotEmpty()) {
                            Text(
                                text = "${BanglaUtils.toBangla(products.size.toString())} টি পণ্য",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(9.dp))

                    if (products.isEmpty()) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(
                                imageVector = Icons.Default.Warning,
                                contentDescription = null,
                                tint = OutflowRed,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(7.dp))
                            Text(
                                text = "কোনো পণ্য নেই। আগে পণ্য যোগ করুন।",
                                fontSize = 13.sp,
                                color = OutflowRed,
                                fontWeight = FontWeight.Medium
                            )
                        }
                    } else if (liveProduct == null) {
                        Button(
                            onClick = { showPicker = true },
                            modifier = Modifier
                                .fillMaxWidth()
                                .testTag("stock_pick_product"),
                            colors = ButtonDefaults.buttonColors(containerColor = TechNavyPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("পণ্য খুঁজুন", fontWeight = FontWeight.Bold)
                        }
                    } else {
                        val p = liveProduct
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(p.name, fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                Text(
                                    text = buildString {
                                        append(p.category)
                                        append(" · একক: ")
                                        append(p.unit)
                                        append(" · বর্তমান স্টক: ")
                                        append(BanglaUtils.toBangla(p.stockQuantity))
                                    },
                                    fontSize = 12.sp,
                                    color = if (p.stockQuantity <= 0) OutflowRed
                                    else MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                                Text(
                                    text = "লাভ প্রতি একক: ${BanglaUtils.formatTaka(p.sellPrice - p.buyPrice, useSymbol = true)}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                                )
                            }
                            TextButton(onClick = { showPicker = true }) {
                                Text("বদলান", color = TechNavyPrimary, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }

            // ---------- 3. mode + quantity + note ----------
            item {
                SectionCard {
                    Text(
                        text = "২. কী করবেন?",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TechNavyPrimary
                    )
                    Spacer(modifier = Modifier.height(9.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        StockAdjustMode.entries.forEach { m ->
                            FilterChip(
                                selected = mode == m,
                                onClick = {
                                    mode = m
                                    qtyInput = ""
                                },
                                label = {
                                    Text(
                                        text = m.banglaLabel,
                                        fontSize = 10.5.sp,
                                        maxLines = 1
                                    )
                                },
                                modifier = Modifier
                                    .weight(1f)
                                    .testTag("stock_mode_${m.name}")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = qtyInput,
                        onValueChange = { raw ->
                            // A stock count is never fractional — digits only.
                            qtyInput = raw.filter { it.isDigit() }.take(6)
                        },
                        label = {
                            Text(
                                if (mode == StockAdjustMode.SET_TO_COUNT) "গণনায় পাওয়া সংখ্যা"
                                else "পরিমাণ"
                            )
                        },
                        placeholder = {
                            Text(
                                if (mode == StockAdjustMode.SET_TO_COUNT) "যেমন: ২৪"
                                else "যেমন: ৫"
                            )
                        },
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("stock_qty_input"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        enabled = liveProduct != null
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = noteInput,
                        onValueChange = { noteInput = it.take(120) },
                        label = { Text("কারণ বা নোট (ঐচ্ছিক)") },
                        placeholder = { Text("যেমন: ভাঙা পণ্য, ফেরত, মাসিক গণনা") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp),
                        enabled = liveProduct != null
                    )
                }
            }

            // ---------- 4. live preview ----------
            item {
                val accent = when {
                    !preview.isValid -> MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    preview.delta > 0 -> InflowGreen
                    preview.delta < 0 -> OutflowRed
                    else -> GoldAccent
                }
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stock_preview"),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = accent.copy(alpha = 0.10f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 0.dp)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "৩. ফলাফল",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = accent
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        when {
                            liveProduct == null -> Text(
                                text = "আগে একটি পণ্য বাছুন।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                            )

                            !preview.isValid -> Text(
                                text = preview.errorMessage ?: "তথ্য অসম্পূর্ণ।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.75f)
                            )

                            else -> {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Column {
                                        Text(
                                            "বর্তমান",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                        Text(
                                            BanglaUtils.toBangla(preview.currentOnHand.toString()),
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold
                                        )
                                    }
                                    Icon(
                                        imageVector = if (preview.delta > 0) Icons.Default.Add
                                        else Icons.Default.Remove,
                                        contentDescription = null,
                                        tint = accent,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Column(horizontalAlignment = Alignment.End) {
                                        Text(
                                            "নতুন স্টক",
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.6f)
                                        )
                                        Text(
                                            BanglaUtils.toBangla(preview.resultingOnHand.toString()),
                                            fontSize = 20.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = accent
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.height(6.dp))
                                val deltaSign = if (preview.delta > 0) "+" else "−"
                                val deltaAbs = BanglaUtils.toBangla(Math.abs(preview.delta).toString())
                                Text(
                                    text = "পরিবর্তন: $deltaSign$deltaAbs · ${mode.banglaLabel}",
                                    fontSize = 12.sp,
                                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.7f)
                                )
                                if (preview.resultingOnHand == 0) {
                                    Spacer(modifier = Modifier.height(6.dp))
                                    Text(
                                        text = "⚠️ স্টক শূন্য হলে পণ্যটি কাস্টমার পোর্টালে অনুপলব্ধ দেখাবে।",
                                        fontSize = 12.sp,
                                        color = OutflowRed,
                                        fontWeight = FontWeight.SemiBold
                                    )
                                }
                            }
                        }
                    }
                }
            }

            // ---------- 5. save ----------
            item {
                Button(
                    onClick = {
                        val p = liveProduct ?: return@Button
                        val result = computeStockAdjustPreview(currentOnHand, mode, inputQty)

                        if (!result.isValid) {
                            Toast.makeText(
                                context,
                                result.errorMessage ?: "সমন্বয় করা যায়নি",
                                Toast.LENGTH_SHORT
                            ).show()
                            return@Button
                        }

                        // লেজারে লেখা হয় — recordStockMovement() একই ট্রানজেকশনে
                        // মুভমেন্ট রেকর্ড করে ও products.stockQuantity হালনাগাদ করে।
                        viewModel.adjustStock(p, mode, inputQty, noteInput.trim()) { newOnHand ->
                            if (newOnHand == null) {
                                Toast.makeText(context, "সমন্বয় করা যায়নি", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(
                                    context,
                                    "স্টক সমন্বয় সংরক্ষিত! নতুন স্টক: " +
                                        BanglaUtils.toBangla(newOnHand.toString()),
                                    Toast.LENGTH_SHORT
                                ).show()
                            }
                        }

                        qtyInput = ""
                        noteInput = ""
                    },
                    enabled = liveProduct != null && preview.isValid,
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("stock_save_button"),
                    colors = ButtonDefaults.buttonColors(containerColor = InflowGreen),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(18.dp))
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = "সমন্বয় সংরক্ষণ করুন",
                        fontWeight = FontWeight.Bold,
                        fontSize = 15.sp
                    )
                }
            }

            // ---------- 6. recent adjustments ----------
            item {
                Spacer(modifier = Modifier.height(4.dp))
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(
                        imageVector = Icons.Default.Receipt,
                        contentDescription = null,
                        tint = TechNavyPrimary,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(7.dp))
                    Text(
                        text = "সাম্প্রতিক সমন্বয়",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.weight(1f))
                    Text(
                        text = "লেজার থেকে",
                        fontSize = 10.5.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f)
                    )
                }
            }

            if (recentMovements.isEmpty()) {
                item {
                    Text(
                        text = "এখনো কোনো সমন্বয় করা হয়নি।",
                        fontSize = 13.sp,
                        color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                        modifier = Modifier.padding(vertical = 8.dp)
                    )
                }
            } else {
                itemsIndexed(recentMovements) { _, movement ->
                    MovementRow(movement = movement)
                }
            }

            item { Spacer(modifier = Modifier.height(28.dp)) }
        }
    }

    // ---------- product picker dialog ----------
    if (showPicker) {
        var query by remember { mutableStateOf("") }
        val filtered = products.filter {
            query.isBlank() ||
                it.name.contains(query, ignoreCase = true) ||
                it.category.contains(query, ignoreCase = true)
        }

        AlertDialog(
            onDismissRequest = { showPicker = false },
            title = { Text("পণ্য বাছুন") },
            text = {
                Column {
                    OutlinedTextField(
                        value = query,
                        onValueChange = { query = it },
                        placeholder = { Text("নাম বা ক্যাটাগরি লিখুন...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("stock_picker_search"),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.4f))
                    Spacer(modifier = Modifier.height(6.dp))

                    if (filtered.isEmpty()) {
                        Text(
                            text = "কোনো পণ্য পাওয়া যায়নি।",
                            fontSize = 13.sp,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.5f),
                            modifier = Modifier.padding(vertical = 12.dp)
                        )
                    } else {
                        LazyColumn(modifier = Modifier.height(300.dp)) {
                            itemsIndexed(filtered) { _, row ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .clickable {
                                            selectedProduct = row
                                            qtyInput = ""
                                            showPicker = false
                                        }
                                        .padding(vertical = 11.dp, horizontal = 4.dp)
                                        .testTag("stock_picker_item_${row.id}"),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.Inventory2,
                                        contentDescription = null,
                                        tint = if (row.stockQuantity <= 0) OutflowRed else TechNavyPrimary,
                                        modifier = Modifier.size(18.dp)
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(row.name, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                                        Text(
                                            text = "${row.category} · স্টক: ${BanglaUtils.toBangla(row.stockQuantity)}",
                                            fontSize = 11.5.sp,
                                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                                        )
                                    }
                                    if (row.stockQuantity <= 0) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = OutflowRed.copy(alpha = 0.14f)
                                        ) {
                                            Text(
                                                text = "শেষ",
                                                fontSize = 10.sp,
                                                fontWeight = FontWeight.Bold,
                                                color = OutflowRed,
                                                modifier = Modifier.padding(horizontal = 7.dp, vertical = 3.dp)
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { showPicker = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

// ---------- small building blocks ----------

@Composable
private fun SectionCard(content: @Composable ColumnScope.() -> Unit) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(14.dp), content = content)
    }
}

@Composable
private fun HeaderStat(
    label: String,
    value: String,
    accent: Color,
    modifier: Modifier = Modifier
) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        color = Color.White.copy(alpha = 0.08f)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 8.dp)) {
            Text(label, fontSize = 10.5.sp, color = Color.White.copy(alpha = 0.75f))
            Text(value, fontSize = 17.sp, fontWeight = FontWeight.Bold, color = accent)
        }
    }
}

private fun BrandCyanish(): Color = BrandCyanLight

/** One row in the recent-adjustments list — reads straight from the ledger. */
@Composable
private fun MovementRow(movement: StockMovementEntity) {
    val accent = if (movement.isInflow) InflowGreen else OutflowRed
    val typeLabel = StockMovementType.fromString(movement.type).banglaLabel

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = accent.copy(alpha = 0.14f),
                modifier = Modifier.size(34.dp)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(
                        imageVector = if (movement.isInflow) Icons.Default.Add else Icons.Default.Remove,
                        contentDescription = null,
                        tint = accent,
                        modifier = Modifier.size(17.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.width(11.dp))
            Column(modifier = Modifier.weight(1f)) {
                Text(movement.productName, fontSize = 14.sp, fontWeight = FontWeight.SemiBold)
                Text(
                    text = movement.reason.ifBlank { typeLabel },
                    fontSize = 11.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.65f)
                )
            }
            Column(horizontalAlignment = Alignment.End) {
                Text(
                    text = (if (movement.isInflow) "+" else "−") +
                        BanglaUtils.toBangla(Math.abs(movement.delta).toString()),
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = accent
                )
                Text(
                    text = BanglaUtils.formatDateToBangla(movement.occurredAt),
                    fontSize = 10.5.sp,
                    color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.55f)
                )
            }
        }
    }
}
