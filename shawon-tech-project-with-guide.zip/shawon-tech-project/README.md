# Shawon Tech And Electronics — Android অ্যাপ

Kotlin + Jetpack Compose + Room + Firebase দিয়ে তৈরি দোকান ব্যবস্থাপনা অ্যাপ।
বাংলা UI, ইনভেন্টরি/স্টক লেজার, বিক্রয়-ক্রয়, কাস্টমার ও বাকির হিসাব।

- **Package:** `com.example`
- **Application ID:** `com.aistudio.shawontech.txmgr`
- **compileSdk / targetSdk:** 36 (minor API level 1)
- **minSdk:** 24
- **Kotlin:** 2.2.10 · **AGP:** 9.1.1 · **Gradle:** 9.3.1 · **Room:** 2.7.0

> মূল AI Studio প্রজেক্ট: https://ai.studio/apps/88cd19e9-c0c7-4bc4-8b75-acb529ba76a2

---

## ১. যা যা দরকার (Prerequisites)

| টুল | ভার্সন | মন্তব্য |
|---|---|---|
| Android Studio | Ladybug বা নতুন | Android Studio নিজেই JDK বান্ডল করে |
| JDK | **17 বা 21** | 21 হলে Robolectric টেস্টও চলবে |
| Android SDK | **platforms;android-36.1** | শুধু `android-36` নয় — minor API level 1 দরকার |
| Build Tools | 36.0.0 | |
| Platform Tools | সর্বশেষ | |

> ⚠️ **গুরুত্বপূর্ণ:** প্রজেক্টে লেখা আছে `compileSdk { version = release(36) { minorApiLevel = 1 } }`।
> অর্থাৎ সাধারণ `android-36` নয়, **`android-36.1`** প্ল্যাটফর্ম দরকার। শুধু `android-36` ইনস্টল
> করলে বিল্ড "failed to find target" এরর দেবে।

---

## ২. Android Studio-তে খোলা ও চালানো

### ধাপ ১ — প্রজেক্ট খুলুন
1. Android Studio চালু করুন → **Open**
2. এই ZIP খুলে যে ফোল্ডারটি বেরোয় (যেখানে `settings.gradle.kts` আছে) সেটি বেছে নিন
3. Gradle sync শেষ হওয়া পর্যন্ত অপেক্ষা করুন

### ধাপ ২ — Android SDK সেট করুন
`local.properties` ফাইলটি প্রজেক্টের রুটে তৈরি করুন (ZIP-এ ইচ্ছাকৃতভাবে দেওয়া হয়নি, কারণ
প্রতিটি মেশিনে SDK-র পাথ আলাদা):

```properties
sdk.dir=/path/to/your/Android/Sdk
```

- **Linux/macOS:** সাধারণত `~/Android/Sdk`
- **Windows:** সাধারণত `C:\\Users\\<আপনার-নাম>\\AppData\\Local\\Android\\Sdk`

Android Studio সাধারণত নিজেই এই ফাইলটি বানিয়ে দেয়। SDK Manager
(**Tools → SDK Manager → SDK Platforms**) থেকে নিশ্চিত করুন:
- ✅ Android 36.1 (API 36, minor level 1)
- ✅ Android SDK Build-Tools 36.0.0
- ✅ Android SDK Platform-Tools

### ধাপ ৩ — `.env` ফাইল (ঐচ্ছিক)
Firebase/Gemini কী দরকার হলে `.env.example` কপি করে `.env` বানান:

```bash
cp .env.example .env
# তারপর .env-এ GEMINI_API_KEY=... বসান
```

> `google-services.json` ZIP-এ দেওয়া আছে, তাই Firebase কনফিগ নিয়ে চিন্তা নেই।
> `googleServices.missing.passthrough=true` থাকায় ফাইল না থাকলেও বিল্ড ভাঙবে না।

### ধাপ ৪ — কমান্ড লাইন থেকে বিল্ড (ঐচ্ছিক)

```bash
# শুধু Kotlin কম্পাইল (দ্রুত যাচাই)
./gradlew :app:compileDebugKotlin

# সম্পূর্ণ ডিবাগ APK
./gradlew :app:assembleDebug

# ইউনিট টেস্ট (মাইগ্রেশন টেস্টসহ)
./gradlew :app:testDebugUnitTest
```

APK তৈরি হবে: `app/build/outputs/apk/debug/app-debug.apk`

### ধাপ ৫ — চালান
Android Studio-তে উপরে ডিভাইস/এমুলেটর বেছে **Run ▶** চাপুন।

---

## ৩. পরিচিত সমস্যা ও সমাধান

### 🔴 Gradle ডেমন "disappeared unexpectedly" / OOM ক্র্যাশ
**কারণ:** `gradle.properties`-এ `-Xmx4g` লেখা থাকলে JVM ৪ GiB heap চায়। কম RAM-এর
মেশিন বা কনটেইনারে (২ GiB সীমা) OOM-killer প্রসেস মেরে দেয়।

**সমাধান:** `gradle.properties`-এ jvmargs কমান:

```properties
org.gradle.jvmargs=-Xmx2048m -XX:MaxMetaspaceSize=512m -Dfile.encoding=UTF-8
```

> এই ZIP-এ ইতিমধ্যে `-Xmx1024m` সেট করা আছে (২ GiB কনটেইনারে বিল্ড সফল হয়েছে)।
> **আপনার নিজের মেশিনে ৮–১৬ GiB RAM থাকলে `-Xmx4g` দিলে বিল্ড দ্রুততর হবে।**

### 🔴 "Could not connect to Kotlin compile daemon"
`gradle.properties`-এ ইতিমধ্যে সমাধান দেওয়া আছে:
```properties
kotlin.compiler.execution.strategy=in-process
```

### 🔴 "Failed to find target with hash string 'android-36.1'"
SDK Manager থেকে **Android 36.1** প্ল্যাটফর্ম ইনস্টল করুন (শুধু `android-36` নয়)।

### 🔴 Robolectric টেস্ট "requires Java 21"
Robolectric SDK 36-এর জন্য JDK 21 দরকার। Android Studio-তে
**Settings → Build → Build Tools → Gradle → Gradle JDK** থেকে JDK 21 বেছে নিন।
(মাইগ্রেশন টেস্ট `MigrationV5ToV7Test.kt` JDK 17-এও চলে, কারণ সেটি pure-JVM SQLite ব্যবহার করে।)

### 🟡 "signingConfig debugConfig" সংক্রান্ত সতর্কতা
`app/build.gradle.kts`-এ AI Studio-র জন্য debug signing config সেট করা আছে।
নিজের মেশিনে সাধারণ ডিবাগ বিল্ডের জন্য এটি সমস্যা করে না।

---

## ৪. প্রজেক্ট স্ট্রাকচার

```
.
├── app/
│   ├── build.gradle.kts              # অ্যাপ মডিউল কনফিগ
│   ├── google-services.json          # Firebase কনফিগ
│   ├── schemas/                      # Room স্কিমা JSON (মাইগ্রেশন যাচাইয়ের জন্য)
│   │   └── com.example.data.local.AppDatabase/7.json
│   └── src/
│       ├── main/
│       │   ├── AndroidManifest.xml
│       │   ├── java/com/example/
│       │   │   ├── data/
│       │   │   │   ├── local/        # Room: AppDatabase, DAO, Migrations, StockMovementDao
│       │   │   │   ├── model/        # ডেটা মডেল (StockMovement সহ)
│       │   │   │   ├── remote/       # FirestoreSyncService
│       │   │   │   ├── repository/   # রিপোজিটরি
│       │   │   │   └── sample/       # নমুনা ডেটা
│       │   │   ├── ui/
│       │   │   │   ├── components/   # QuickActionSheet ইত্যাদি
│       │   │   │   ├── screens/      # সব স্ক্রিন (StockAdjustScreen, ProductManagementScreen…)
│       │   │   │   ├── theme/        # রঙ, টাইপোগ্রাফি
│       │   │   │   └── viewmodel/    # DashboardViewModel
│       │   │   └── util/
│       │   └── res/                  # strings.xml (বাংলা), drawable, mipmap, xml
│       ├── test/                     # JVM ইউনিট টেস্ট (MigrationV5ToV7Test সহ)
│       └── androidTest/              # ইনস্ট্রুমেন্টেড টেস্ট
├── gradle/
│   ├── libs.versions.toml            # ভার্সন ক্যাটালগ
│   └── wrapper/                      # gradle-wrapper.jar + properties
├── gradlew / gradlew.bat             # Gradle wrapper স্ক্রিপ্ট
├── build.gradle.kts                  # রুট বিল্ড ফাইল
├── settings.gradle.kts
├── gradle.properties                 # JVM/মেমোরি সেটিং
├── firebase-blueprint.json
├── firestore.rules
└── .env.example
```

---

## ৫. এ পর্যন্ত সম্পন্ন কাজের সারসংক্ষেপ

### ১৩টি খোলা কাজ — সব সম্পূর্ণ ✅

| আইডি | কাজ | অবস্থা |
|---|---|---|
| B1 | Gradle wrapper সম্পূর্ণ (gradlew + .bat + jar, Gradle 9.3.1) | ✅ |
| B2 | `fallbackToDestructiveMigration()` সরানো + MIGRATION_5_6, MIGRATION_6_7 | ✅ |
| I1 | StockAdjustScreen নেভিগেশনে যুক্ত + quick-action প্লেসহোল্ডার প্রতিস্থাপন | ✅ |
| I2 | স্টক লেজার — StockMovementEntity, StockMovementDao, `recordStockMovement()`, ProductStockRow | ✅ |
| I3 | বিক্রয়/ক্রয়ে স্টক আউট/ইন — EntryFormScreen-এ প্রোডাক্ট পিকার | ✅ |
| I4 | প্রোডাক্ট, কাস্টমার, পেমেন্ট রিকোয়েস্ট ও লেজার Firestore সিঙ্ক | ✅ |
| I5 | reorderPoint ভিত্তিক লো-স্টক ব্যাজ | ✅ |
| I6 | সাম্প্রতিক তালিকা লেজার থেকে স্থায়ী | ✅ |
| O1–O5 | navigation কমেন্ট, firebase.ai সরানো, পণ্য স্ক্রিন, ৫-ট্যাব+আরও, exportSchema | ✅ |

### যাচাইয়ের ফলাফল

- **Kotlin কম্পাইল:** `./gradlew :app:compileDebugKotlin` → **BUILD SUCCESSFUL** (০টি এরর)
- **মাইগ্রেশন টেস্ট:** `MigrationV5ToV7Test` → **৫/৫ পাস**
  - v5 → v7 ডেটা অক্ষত (পণ্য, কাস্টমার, লেনদেন, পেমেন্ট)
  - `stock_movements` টেবিল সঠিক ১১টি কলাম নিয়ে তৈরি
  - `7.json` স্কিমার সাথে হুবহু মিল
  - আলাদা ধাপে (v5→v6→v7) ও একসাথে — দুটোই যাচাই
- **নতুন ফাইল:** StockMovement.kt, StockMovementDao.kt, Migrations.kt, QuickActionSheet.kt,
  ProductManagementScreen.kt, MigrationV5ToV7Test.kt

---

## ৬. বাকি ঝুঁকি

| ঝুঁকি | মাত্রা | ব্যাখ্যা |
|---|---|---|
| শুধু `compileDebugKotlin` চালানো হয়েছে | মাঝারি | `assembleDebug` (APK প্যাকেজিং, DEX, রিসোর্স মার্জ) চালানো হয়নি |
| আসল ডিভাইসে চালানো হয়নি | স্বাভাবিক | কম্পাইল সফল = টাইপ-সঠিক, কিন্তু রানটাইম UI/ডেটাবেস যাচাই বাকি |
| Room identityHash ভ্যালিডেশন | নিম্ন | 7.json-এর সাথে মিলিয়ে যাচাই হয়েছে; আসল ডিভাইসে প্রথম চালানোর সময় Room নিজে যাচাই করবে |
| v4 বা তার আগের ডেটাবেস | নিম্ন | v4 → v5 মাইগ্রেশন নেই; পুরোনো ডেটাবেস এলে Room স্পষ্টভাবে ব্যর্থ হবে (নিঃশব্দে মুছবে না) |

---

*এই README-টি প্রযুক্তিগত সেটআপ নির্দেশনা — আর্থিক/কর/আইনি পরামর্শ নয়।*
